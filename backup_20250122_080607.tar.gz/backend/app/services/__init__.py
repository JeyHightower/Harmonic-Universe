"""Services package initialization."""
from .notification import notification_service

__all__ = ['notification_service']
