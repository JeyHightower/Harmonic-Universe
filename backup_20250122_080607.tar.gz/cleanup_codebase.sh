#!/bin/bash

# Enable debugging
set -x

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Function to print section headers
print_header() {
    echo -e "\n${BLUE}=== $1 ===${NC}\n"
}

# Function to print progress
print_progress() {
    echo -e "${YELLOW}>>> $1${NC}"
}

# Function to check if a command was successful
check_status() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ $1 completed successfully${NC}"
    else
        echo -e "${RED}✗ $1 failed${NC}"
        return 1
    fi
}

# Clean up temporary and build files
cleanup_temp_files() {
    print_header "Cleaning Temporary Files"

    print_progress "Removing Python cache files..."
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true

    print_progress "Removing test cache..."
    find . -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true

    print_progress "Removing coverage files..."
    find . -type f -name ".coverage" -delete 2>/dev/null || true
    rm -rf htmlcov/ 2>/dev/null || true

    print_progress "Removing system files..."
    find . -type f -name ".DS_Store" -delete 2>/dev/null || true

    print_progress "Removing log files..."
    find . -type f -name "*.log" -delete 2>/dev/null || true

    print_progress "Removing temporary files..."
    find . -type f -name "*.swp" -delete 2>/dev/null || true
    find . -type f -name ".env.local" -delete 2>/dev/null || true
    find . -type f -name "*.bak" -delete 2>/dev/null || true

    print_progress "Removing build directories..."
    rm -rf build/ dist/ *.egg-info/ 2>/dev/null || true
    rm -rf frontend/build/ frontend/dist/ 2>/dev/null || true

    check_status "Temporary file cleanup"
}

# Organize source code
organize_source() {
    print_header "Organizing Source Code"

    print_progress "Creating backend directory structure..."
    mkdir -p backend/{app,tests,docs,scripts}
    mkdir -p backend/app/{models,routes,services,utils}
    mkdir -p backend/tests/{unit,integration,e2e}

    print_progress "Creating frontend directory structure..."
    mkdir -p frontend/{src,tests,public,docs}
    mkdir -p frontend/src/{components,services,utils,styles}
    mkdir -p frontend/tests/{unit,integration,e2e}

    check_status "Source code organization"
}

# Consolidate documentation
organize_docs() {
    print_header "Organizing Documentation"

    print_progress "Creating documentation directories..."
    mkdir -p docs/{api,setup,testing,features}

    print_progress "Moving documentation files..."
    [ -f docs/API.md ] && mv docs/API.md docs/api/README.md
    [ -f docs/SETUP.md ] && mv docs/SETUP.md docs/setup/README.md
    [ -f docs/TEST_PLAN.md ] && mv docs/TEST_PLAN.md docs/testing/TEST_PLAN.md

    check_status "Documentation organization"
}

# Organize test files
organize_tests() {
    print_header "Organizing Tests"

    print_progress "Creating test directories..."
    mkdir -p tests/{unit,integration,e2e,setup}

    print_progress "Moving Python test files..."
    find . -name "*test*.py" -not -path "./tests/*" -not -path "./venv/*" -exec mv -f {} tests/unit/ \; 2>/dev/null || true

    print_progress "Moving JavaScript test files..."
    find . -name "*test*.js" -not -path "./tests/*" -not -path "./node_modules/*" -exec mv -f {} tests/unit/ \; 2>/dev/null || true

    check_status "Test organization"
}

# Clean up node modules
cleanup_node_modules() {
    print_header "Cleaning Node Modules"

    if [ -f "frontend/package.json" ]; then
        print_progress "Removing node_modules..."
        rm -rf frontend/node_modules

        print_progress "Reinstalling dependencies..."
        cd frontend
        npm install --silent
        cd ..
    fi

    check_status "Node modules cleanup"
}

# Clean up Python virtual environments
cleanup_venv() {
    print_header "Cleaning Python Virtual Environments"

    if [ -f "backend/requirements.txt" ]; then
        print_progress "Removing existing venv..."
        rm -rf backend/venv

        print_progress "Creating new venv..."
        cd backend
        python3 -m venv venv

        print_progress "Installing dependencies..."
        source venv/bin/activate
        pip install -r requirements.txt --quiet
        deactivate
        cd ..
    fi

    check_status "Virtual environment cleanup"
}

# Update gitignore
update_gitignore() {
    print_header "Updating .gitignore"
    print_progress "Writing new .gitignore..."

    cat << EOF > .gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST
.env
venv/
.coverage
htmlcov/

# Node
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.pnpm-debug.log*
.env.local
.env.development.local
.env.test.local
.env.production.local

# IDE
.idea/
.vscode/
*.swp
*.swo
*~

# OS
.DS_Store
.AppleDouble
.LSOverride
Thumbs.db

# Testing
.pytest_cache/
coverage/
.nyc_output/
cypress/videos/
cypress/screenshots/

# Build
frontend/build/
frontend/dist/
backend/build/
backend/dist/

# Logs
*.log
logs/
log/

# Environment
.env*
!.env.example

# Database
*.sqlite
*.db

# Temporary files
*.tmp
*.temp
*.bak
EOF

    check_status "Gitignore update"
}

# Main execution
print_header "Starting Codebase Cleanup"

# Create backup
print_header "Creating Backup"
timestamp=$(date +%Y%m%d_%H%M%S)
print_progress "Creating backup archive..."
tar -czf "backup_${timestamp}.tar.gz" --exclude="node_modules" --exclude="venv" --exclude=".git" .
check_status "Backup creation"

# Run cleanup tasks
cleanup_temp_files || true
organize_source || true
organize_docs || true
organize_tests || true
cleanup_node_modules || true
cleanup_venv || true
update_gitignore || true

print_header "Cleanup Complete"
echo "A backup of the original codebase is available at: backup_${timestamp}.tar.gz"

# Disable debugging
set +x
