"""Universe model."""
from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.orm import relationship
from typing import Dict, Any, Optional
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text, JSON
from sqlalchemy.sql import or_
from .base import BaseModel


class Universe(BaseModel):
    """Universe model for storing universe related details."""

    __tablename__ = "universes"
    __table_args__ = (
        db.Index("idx_user_id", "user_id"),
        db.Index("idx_is_public", "is_public"),
        db.Index("idx_created_at", "created_at"),
        db.Index("idx_name", "name"),
    )

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    is_public = Column(Boolean, default=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    # Parameters
    physics_params = Column(JSON, default=dict)  # Gravity, friction, etc.
    music_params = Column(JSON, default=dict)    # Harmony, tempo, etc.
    visual_params = Column(JSON, default=dict)   # Colors, shapes, etc.

    # Relationships
    user = relationship("User", back_populates="universes")
    storyboards = relationship("Storyboard", back_populates="universe", cascade="all, delete-orphan")

    def __init__(
        self,
        name: str,
        description: str = None,
        is_public: bool = False,
        user_id: int = None,
        physics_params: dict = None,
        music_params: dict = None,
        visual_params: dict = None,
    ):
        self.name = name
        self.description = description
        self.is_public = is_public
        self.user_id = user_id
        self.physics_params = physics_params or {}
        self.music_params = music_params or {}
        self.visual_params = visual_params or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert universe to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "is_public": self.is_public,
            "user_id": self.user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "physics_params": self.physics_params,
            "music_params": self.music_params,
            "visual_params": self.visual_params,
            "user": self.user.to_dict() if self.user else None,
        }

    @staticmethod
    def validate_physics_params(params):
        """Validate physics parameters."""
        if not isinstance(params, dict):
            return False, "Parameters must be a dictionary"

        required_params = ['gravity', 'friction', 'elasticity', 'air_resistance']
        for param in required_params:
            if param not in params:
                return False, f"Missing required parameter: {param}"

            value = params[param]
            if not isinstance(value, (int, float)):
                return False, f"Parameter {param} must be a number"

            if param == 'gravity' and value <= 0:
                return False, "Gravity must be positive"
            elif param in ['friction', 'elasticity', 'air_resistance']:
                if not 0 <= value <= 1:
                    return False, f"{param} must be between 0 and 1"

        return True, None

    @staticmethod
    def validate_music_params(params):
        """Validate music parameters."""
        if not isinstance(params, dict):
            return False, "Parameters must be a dictionary"

        required_params = ['harmony', 'tempo', 'key', 'scale']
        for param in required_params:
            if param not in params:
                return False, f"Missing required parameter: {param}"

            value = params[param]
            if param == 'tempo':
                if not isinstance(value, (int, float)) or not 20 <= value <= 300:
                    return False, "Tempo must be between 20 and 300 BPM"
            elif param in ['harmony', 'key', 'scale']:
                if not isinstance(value, str):
                    return False, f"{param} must be a string"

        return True, None

    @staticmethod
    def validate_visual_params(params):
        """Validate visualization parameters."""
        if not isinstance(params, dict):
            return False, "Parameters must be a dictionary"

        required_params = ['color_scheme', 'particle_size', 'trail_length']
        for param in required_params:
            if param not in params:
                return False, f"Missing required parameter: {param}"

            value = params[param]
            if param == 'color_scheme':
                if not isinstance(value, str):
                    return False, "Color scheme must be a string"
            elif param in ['particle_size', 'trail_length']:
                if not isinstance(value, (int, float)) or value <= 0:
                    return False, f"{param} must be a positive number"

        return True, None

    def update_parameters(self, param_type: str, new_params: dict) -> tuple[bool, Optional[str]]:
        """Update parameters of specified type."""
        validators = {
            'physics': self.validate_physics_params,
            'music': self.validate_music_params,
            'visual': self.validate_visual_params
        }

        param_maps = {
            'physics': 'physics_params',
            'music': 'music_params',
            'visual': 'visual_params'
        }

        if param_type not in validators:
            return False, f"Invalid parameter type: {param_type}"

        valid, message = validators[param_type](new_params)
        if not valid:
            return False, message

        setattr(self, param_maps[param_type], new_params)
        return True, None

    def export_to_json(self) -> Dict[str, Any]:
        """Export universe configuration to JSON."""
        return {
            "name": self.name,
            "description": self.description,
            "physics_params": self.physics_params,
            "music_params": self.music_params,
            "visual_params": self.visual_params,
            "exported_at": datetime.now(timezone.utc).isoformat()
        }

    def __repr__(self):
        return f"<Universe {self.name}>"
