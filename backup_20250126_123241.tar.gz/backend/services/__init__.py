from .websocket import init_socketio

__all__ = ['init_socketio']
