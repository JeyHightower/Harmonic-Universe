"""Universe routes module."""
from .universe_routes import universe_bp

__all__ = ['universe_bp']
